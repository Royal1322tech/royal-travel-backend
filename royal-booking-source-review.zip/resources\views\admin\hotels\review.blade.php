@extends('admin.layouts.app')

@section('content')
<div class="mx-auto max-w-5xl space-y-6 px-4 py-6">
    {{-- Page heading --}}
    <div class="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
        <p class="text-xs font-bold uppercase tracking-widest text-[#B7731E]">Hotel Management / Booking Review</p>
        <h1 class="mt-2 text-2xl font-bold text-[#02143C]">Review your selected room</h1>
        <p class="mt-2 text-sm text-slate-600">Availability was rechecked. No reservation or payment has been made.</p>
    </div>

    @if ($priceChanged)
        <div role="alert" class="rounded-xl border border-amber-200 bg-amber-50 p-4 text-sm text-amber-900">
            The supplier reported a price change. The final customer-facing price must be verified before booking.
        </div>
    @endif

    {{-- Stay details --}}
    <section class="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm" aria-label="Booking details">
        <h2 class="text-lg font-bold text-[#02143C]">Stay details</h2>
        <dl class="mt-5 grid gap-5 sm:grid-cols-2">
            <div><dt class="text-xs font-semibold uppercase text-slate-500">Hotel</dt><dd class="mt-1 font-semibold text-slate-900">{{ $hotelName }}</dd></div>
            <div><dt class="text-xs font-semibold uppercase text-slate-500">Room</dt><dd class="mt-1 font-semibold text-slate-900">{{ $roomName }}</dd></div>
            <div><dt class="text-xs font-semibold uppercase text-slate-500">Meal plan</dt><dd class="mt-1 text-slate-800">{{ $mealName }}</dd></div>
            <div><dt class="text-xs font-semibold uppercase text-slate-500">Rooms requested</dt><dd class="mt-1 text-slate-800">{{ $guestRooms }}</dd></div>
            <div><dt class="text-xs font-semibold uppercase text-slate-500">Check-in</dt><dd class="mt-1 text-slate-800">{{ $checkin }}</dd></div>
            <div><dt class="text-xs font-semibold uppercase text-slate-500">Check-out</dt><dd class="mt-1 text-slate-800">{{ $checkout }}</dd></div>
        </dl>
    </section>

    {{-- Price and cancellation conditions --}}
    <section class="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm" aria-label="Price and conditions">
        <h2 class="text-lg font-bold text-[#02143C]">Price &amp; conditions</h2>
        <div class="mt-5 rounded-xl border border-slate-200 bg-slate-50 p-5">
            <p class="text-xs font-semibold uppercase tracking-wide text-slate-500">Final selling price</p>
            @if (($priceReview['verified'] ?? false) === true)
                <p class="mt-2 text-xl font-bold text-[#02143C]">{{ $priceReview['amount'] }} {{ $priceReview['currency'] }}</p>
                <p class="mt-2 text-xs text-slate-500">Royal selling price for the selected stay. Booking and payment are subject to final validation.</p>
            @else
                <p class="mt-2 text-base font-semibold text-amber-800">Price on request</p>
                <p class="mt-2 text-xs text-slate-500">Final price is unavailable until supplier total, taxes and fees are verified. No booking or payment has been made.</p>
            @endif
        </div>

        <div class="mt-5 rounded-xl border border-slate-200 p-5">
            <h3 class="text-base font-bold text-[#02143C]">Cancellation Policy</h3>
            @if (isset($cancellationPolicy) && is_array($cancellationPolicy) && ($cancellationPolicy['verified'] ?? false) === true)
                @if (!empty($cancellationPolicy['free_cancellation_until']))
                    @if ($cancellationPolicy['free_cancellation_active'] ?? false)
                        <div class="mt-4 rounded-lg border border-emerald-200 bg-emerald-50 p-4">
                            <p class="font-semibold text-emerald-800">Free cancellation available</p>
                            <p class="mt-1 text-sm text-emerald-700">Cancel before {{ $cancellationPolicy['free_cancellation_until'] }} without a cancellation penalty.</p>
                        </div>
                    @else
                        <div class="mt-4 rounded-lg border border-amber-200 bg-amber-50 p-4">
                            <p class="font-semibold text-amber-900">Free cancellation period has ended</p>
                            <p class="mt-1 text-sm text-amber-800">The free cancellation deadline was {{ $cancellationPolicy['free_cancellation_until'] }}. Cancellation penalties may now apply.</p>
                        </div>
                    @endif
                @endif
                @if (!empty($cancellationPolicy['penalty_description']))
                    <div class="mt-3 rounded-lg border border-amber-200 bg-amber-50 p-4">
                        <p class="font-semibold text-amber-900">Cancellation penalty</p>
                        <p class="mt-1 text-sm text-amber-800">{{ $cancellationPolicy['penalty_description'] }}</p>
                    </div>
                @endif
                @if (!empty($cancellationPolicy['timezone']))
                    <p class="mt-3 text-xs text-slate-500">All cancellation deadlines are shown in: {{ $cancellationPolicy['timezone'] }}</p>
                @endif
            @else
                <div class="mt-4 rounded-lg bg-slate-50 p-4">
                    <p class="text-sm font-medium text-slate-700">Cancellation policy details are pending verification.</p>
                    <p class="mt-2 text-xs text-slate-500">Cancellation deadlines and penalties will be shown after the supplier policy is fully validated.</p>
                </div>
            @endif
        </div>

        {{-- Booking form: requires controller-provided token, companies and roomOccupancies. --}}
        <div class="mt-6 border-t border-slate-200 pt-5">
            <h3 class="text-lg font-bold text-[#02143C]">Complete booking details</h3>
            @if ($errors->any())
                <div role="alert" class="mt-4 rounded-xl border border-red-200 bg-red-50 p-4 text-sm text-red-800">
                    <ul class="list-disc space-y-1 pl-5">
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif

            @if (!empty($token))
                <form method="POST" action="{{ route('admin.hotels.rooms.confirm', ['token' => $token]) }}" class="mt-5 space-y-5">
                    @csrf
                    <div>
                        <label for="company_id" class="block text-sm font-semibold text-slate-800">B2B Company</label>
                        <select id="company_id" name="company_id" required class="mt-2 w-full rounded-xl border border-slate-300 bg-white p-3">
                            <option value="">Select company</option>
                            @foreach (($companies ?? []) as $company)
                                <option value="{{ $company->id }}" @selected(old('company_id') === (string) $company->id)>
                                    {{ $company->name ?? $company->legal_name ?? $company->id }}
                                </option>
                            @endforeach
                        </select>
                    </div>

                    @foreach (($roomOccupancies ?? []) as $roomIndex => $occupancy)
                        <fieldset class="rounded-xl border border-slate-200 p-4">
                            <legend class="px-2 font-bold text-[#02143C]">Room {{ $roomIndex + 1 }} — Guest details</legend>
                            @foreach (($occupancy['guests'] ?? []) as $guestIndex => $guest)
                                <div class="mt-4">
                                    <p class="mb-2 text-xs font-semibold uppercase text-slate-500">Guest {{ $guestIndex + 1 }}</p>
                                    <div class="grid gap-3 sm:grid-cols-2">
                                        <div>
                                            <label for="guest_{{ $roomIndex }}_{{ $guestIndex }}_first" class="block text-xs font-medium text-slate-700">First name</label>
                                            <input id="guest_{{ $roomIndex }}_{{ $guestIndex }}_first" type="text"
                                                name="rooms[{{ $roomIndex }}][guests][{{ $guestIndex }}][first_name]"
                                                value="{{ old("rooms.$roomIndex.guests.$guestIndex.first_name") }}"
                                                maxlength="50" required autocomplete="off"
                                                class="mt-1 w-full rounded-xl border border-slate-300 p-3">
                                        </div>
                                        <div>
                                            <label for="guest_{{ $roomIndex }}_{{ $guestIndex }}_last" class="block text-xs font-medium text-slate-700">Last name</label>
                                            <input id="guest_{{ $roomIndex }}_{{ $guestIndex }}_last" type="text"
                                                name="rooms[{{ $roomIndex }}][guests][{{ $guestIndex }}][last_name]"
                                                value="{{ old("rooms.$roomIndex.guests.$guestIndex.last_name") }}"
                                                maxlength="50" required autocomplete="off"
                                                class="mt-1 w-full rounded-xl border border-slate-300 p-3">
                                        </div>
                                    </div>
                                    {{-- Child age/gender are derived and validated server-side; do not trust client occupancy. --}}
                                </div>
                            @endforeach
                        </fieldset>
                    @endforeach

                    <div class="grid gap-4 sm:grid-cols-2">
                        <div>
                            <label for="contact_email" class="block text-sm font-semibold text-slate-800">Contact email</label>
                            <input id="contact_email" type="email" name="contact_email" value="{{ old('contact_email') }}" required
                                class="mt-2 w-full rounded-xl border border-slate-300 p-3">
                        </div>
                        <div>
                            <label for="contact_phone" class="block text-sm font-semibold text-slate-800">Contact phone</label>
                            <input id="contact_phone" type="tel" name="contact_phone" value="{{ old('contact_phone') }}" required
                                class="mt-2 w-full rounded-xl border border-slate-300 p-3">
                        </div>
                    </div>

                    <div class="rounded-xl border border-slate-200 bg-slate-50 p-4">
                        <p class="font-semibold text-[#02143C]">Payment method</p>
                        <p class="mt-1 text-sm text-slate-700">B2B Company Wallet — USD</p>
                        <p class="mt-2 text-xs text-slate-500">Funds are reserved before supplier booking and captured only after confirmed supplier success.</p>
                    </div>

                    <label class="flex items-start gap-3 text-sm text-slate-700">
                        <input type="checkbox" name="accept_terms" value="1" required @checked(old('accept_terms')) class="mt-1">
                        <span>I have reviewed the final price and cancellation conditions.</span>
                    </label>

                    <button type="submit" @disabled(!($bookingEnabled ?? false))
                        class="rounded-xl bg-[#02143C] px-6 py-3 font-semibold text-white disabled:cursor-not-allowed disabled:opacity-50">
                        Confirm Booking
                    </button>
                    @unless ($bookingEnabled ?? false)
                        <p class="mt-3 text-xs text-amber-800">Booking is not available until server-side pricing, company authorization, occupancy, and supplier confirmation workflow are verified.</p>
                    @endunless
                </form>
            @else
                <p class="mt-4 text-sm text-amber-800">The booking token is unavailable. Please restart the room review.</p>
            @endif
        </div>
    </section>
</div>
@endsection
